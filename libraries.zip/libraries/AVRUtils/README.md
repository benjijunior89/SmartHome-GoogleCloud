# AVRUtils [![Build Status](https://travis-ci.org/SConaway/AVRUtils.svg?branch=master)](https://travis-ci.org/SConaway/AVRUtils)


This is a simple Arduino library to check the internal temperature of an AVR and measure the voltage supplied on `Vcc`.

### Credits
 Temperature-mesauring code based on http://www.instructables.com/id/Hidden-Arduino-Thermometer/
 Code to measure `Vcc` based on https://provideyourown.com/2012/secret-arduino-voltmeter-measure-battery-voltage/
